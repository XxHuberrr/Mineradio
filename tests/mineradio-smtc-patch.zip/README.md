# Mineradio SMTC 媒体控件补丁

## 功能
给 Mineradio 桌面版增加 Windows SMTC（System Media Transport Controls）支持：
- 任务栏音量面板显示歌曲名、歌手、封面
- 媒体卡片播放/暂停/上一曲/下一曲按钮控制播放器
- 实时播放进度条
- 键盘多媒体按键支持

## 修改的文件
```
resources/app/desktop/preload.js          — MediaSession 初始化 + contextBridge 暴露
resources/app/desktop/main.js             — IPC 消息转发（media-control → media-command）
resources/app/public/js/modules/05-playback/14-player-controls.js — 播放器状态同步
```

## 恢复方法
把这三个文件按目录结构覆盖到 Mineradio 安装目录即可：
```
desktop/preload.js          →  Mineradio安装目录/resources/app/desktop/preload.js
desktop/main.js             →  Mineradio安装目录/resources/app/desktop/main.js
public/js/.../14-player-controls.js → 对应路径覆盖
```

## 注意
- 覆盖前建议备份原文件
- 仅适用于未打包成 asar 的 Mineradio 版本（resources/app 为普通文件夹）
- 如果 Mineradio 升级后 resources/app 被重置，重新覆盖本补丁即可
